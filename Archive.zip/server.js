// const http = require('http');

// // Create a simple HTTP server that listens on port 8080
// const server = http.createServer((req, res) => {
//     res.writeHead(200, { 'Content-Type': 'text/html' });
//     res.end('<h1>Hello from the server!</h1>');
// });

// // Bind the server to '0.0.0.0' to make it accessible on all interfaces
// server.listen(8080, '192.168.0.139', () => {
//     console.log('Server running at 10.54.129.3:8080/');
// });
